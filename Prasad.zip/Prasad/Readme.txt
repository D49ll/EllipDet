The rotation angle is in the radian format.  


The List_of_400_Caltech256_Real_Images.txt is the orginal image name provided by Prasad.